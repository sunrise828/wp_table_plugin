<?php

namespace WP_Table_Builder\Inc\Admin;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}